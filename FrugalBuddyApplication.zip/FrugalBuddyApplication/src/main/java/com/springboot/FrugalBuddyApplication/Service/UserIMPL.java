package com.springboot.FrugalBuddyApplication.Service;

import com.springboot.FrugalBuddyApplication.Dto.UserDTO;
import com.springboot.FrugalBuddyApplication.Entity.User;
import com.springboot.FrugalBuddyApplication.Repo.UserRepo;
import com.springboot.FrugalBuddyApplication.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;

public class UserIMPL implements UserService {
    @Autowired
    private UserRepo userRepo;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public String addUser(UserDTO userDTO) {
        User user = new User(
                userDTO.getUserid(),
                userDTO.getUsername(),
                userDTO.getEmail(),
                this.passwordEncoder.encode(userDTO.getPassword())
        );
        userRepo.save(user);
        return user.getUsername();
    }
}
