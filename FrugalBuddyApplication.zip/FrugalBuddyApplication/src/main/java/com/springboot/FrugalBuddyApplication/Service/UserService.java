package com.springboot.FrugalBuddyApplication.Service;

import com.springboot.FrugalBuddyApplication.Dto.UserDTO;

import org.springframework.stereotype.Service;
@Service
public interface UserService {


    String addUser(UserDTO userDTO);
}
