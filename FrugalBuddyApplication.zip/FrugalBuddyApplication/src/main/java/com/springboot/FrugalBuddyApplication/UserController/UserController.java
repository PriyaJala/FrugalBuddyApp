package com.springboot.FrugalBuddyApplication.UserController;

import com.springboot.FrugalBuddyApplication.Dto.UserDTO;


import com.springboot.FrugalBuddyApplication.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("api/v1/user")

public class UserController {

    @Autowired(required = false)
    private UserService userService;
    @PostMapping(path="/save")
    public String saveUser(@RequestBody UserDTO userDTO)
    {
        String id= userService.addUser(userDTO);
        return id;
    }
}
