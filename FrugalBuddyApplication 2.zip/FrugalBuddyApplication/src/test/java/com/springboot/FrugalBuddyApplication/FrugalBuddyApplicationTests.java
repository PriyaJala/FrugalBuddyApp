package com.springboot.FrugalBuddyApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrugalBuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
